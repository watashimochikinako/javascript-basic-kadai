let num = Math.floor(Math.random() * 30);
console.log(num);

if ((num % 5 === 0) && (num % 3 === 0)) {
  console.log('3と5の倍数です')
}
else if (num % 5 === 0) {
  console.log('5の倍数です')
}
else if (num % 3 === 0) {
  console.log('3の倍数です')
}
else {
  console.log(num)
}


// switch (num) {
//   case 0:
//     console.log('3の倍数です')
//     break;
//   case 1:
//     console.log('5の倍数です')
//     break;
//   case 2:
//     console.log('3と5の倍数です')
//     break;
// }